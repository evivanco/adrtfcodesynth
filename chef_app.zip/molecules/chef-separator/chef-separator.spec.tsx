import { ChefSeparator } from './chef-separator';

describe('chef-separator', () => {

  it('builds', () => {
    expect(new ChefSeparator()).toBeTruthy();
  });
});
