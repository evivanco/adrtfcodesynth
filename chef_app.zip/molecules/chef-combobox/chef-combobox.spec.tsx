import { ChefCombobox } from './chef-combobox';

describe('chef-combobox', () => {

  it('exists', () => {
    expect(new ChefCombobox()).toBeTruthy();
  });

});
