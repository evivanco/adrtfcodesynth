import { ChefStepper } from './chef-stepper';

describe('chef-stepper', () => {
  it('renders', () => {
    expect(new ChefStepper()).toBeTruthy();
  });
});
