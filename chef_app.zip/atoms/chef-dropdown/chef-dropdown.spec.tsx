import { ChefDropdown } from './chef-dropdown';

describe('chef-dropdown', () => {

  it('builds', () => {
    expect(new ChefDropdown()).toBeTruthy();
  });
});
