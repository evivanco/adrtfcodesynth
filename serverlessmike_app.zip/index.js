'use strict';

/**
 * Lambda handler para API Gateway (REST o HTTP API) con proxy integration.
 * Retorna HTML directamente.
 */
exports.handler = async (event) => {
  const path = event?.rawPath || event?.path || "/";
  const method = event?.requestContext?.http?.method || event?.httpMethod || "GET";

  // Mini endpoint de salud opcional
  if (path === "/health") {
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store",
      },
      body: JSON.stringify({ ok: true }),
    };
  }

  // Solo respondemos HTML para GET a "/"
  if (method !== "GET") {
    return {
      statusCode: 405,
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Allow": "GET",
      },
      body: "Method Not Allowed",
    };
  }

  const html = `<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Lambda Web</title>
  <style>
    :root {
      color-scheme: light dark;
    }
    body {
      margin: 0;
      font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, "Helvetica Neue", Arial, sans-serif;
      display: grid;
      place-items: center;
      min-height: 100vh;
      background: radial-gradient(circle at top, rgba(120,120,255,.15), transparent 40%),
                  radial-gradient(circle at bottom, rgba(120,255,180,.12), transparent 40%);
    }
    .card {
      width: min(720px, 92vw);
      padding: 28px 26px;
      border-radius: 16px;
      border: 1px solid rgba(128,128,128,.25);
      backdrop-filter: blur(6px);
      background: rgba(255,255,255,.06);
      box-shadow: 0 10px 30px rgba(0,0,0,.12);
    }
    h1 {
      margin: 0 0 8px 0;
      font-size: 1.6rem;
    }
    p {
      margin: 0 0 14px 0;
      opacity: .85;
    }
    code {
      padding: 2px 6px;
      border-radius: 6px;
      background: rgba(128,128,128,.18);
    }
    .row {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
      margin-top: 10px;
    }
    .badge {
      font-size: .85rem;
      padding: 6px 10px;
      border-radius: 999px;
      border: 1px solid rgba(128,128,128,.25);
    }
    a {
      color: inherit;
    }
  </style>
</head>
<body>
  <main class="card">
    <h1>✅ Hola desde AWS Lambda</h1>
    <p>Esta página fue servida por una función <b>Node.js</b> detrás de <b>API Gateway</b>.</p>
    <div class="row">
      <span class="badge">Ruta: <code>${escapeHtml(path)}</code></span>
      <span class="badge">Método: <code>${escapeHtml(method)}</code></span>
      <span class="badge">Runtime esperado: <code>nodejs18.x / nodejs20.x</code></span>
    </div>
    <p style="margin-top:16px">
      Prueba rápida: visita <code>/health</code> para un JSON simple.
    </p>
  </main>
</body>
</html>`;

  return {
    statusCode: 200,
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "no-store",
    },
    body: html,
  };
};

// Sanitización mínima para evitar HTML injection en valores reflejados
function escapeHtml(input) {
  return String(input ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
